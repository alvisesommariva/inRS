

function demo_driver

example=4;

switch example
    case 4

        % EXAMPLE USED IN THE COMPARISONS TABLES OF THE PAPER:
        % Alvise Sommariva and Marco Vianello, "inRS: implementing the 
        % indicator function of NURBS-shaped planar domains".

        domain_typeV=1:3;
        NptsV=[10^3 10^4 10^5];
        
        table1=[]; table2=[];
        for domain_type=domain_typeV
            table1L=[]; table2L=[];
            for Npts=NptsV
                [M0,M1,M2,S01,S21]=demo_nurbs_indomain_04(domain_type,...
                    Npts);
                table1Ladd=[M0;M1;S01]; table1L=[table1L; table1Ladd];
                table2Ladd=[M2;M1;S21]; table2L=[table2L; table2Ladd];
            end
            table1=[table1 table1L];
            table2=[table2 table2L];
        end
        format short e
        table(table1(:,1),table1(:,2),table1(:,3),...
            'VariableNames',{'S3','S4','S5'})
        table(table2(:,1),table2(:,2),table2(:,3),...
            'VariableNames',{'S3','S4','S5'})
end