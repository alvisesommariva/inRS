
function demo_nurbs_indomain_00

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating:
% 1. how to define a NURBS on a composite boundary, using "free NURBS", i.e
%    directly defined from control points, knots, weights and order. 
% 2. how too define a grid that is defined in the bounding box of the
%    domain.
% 3. how to get an indomain test on the desired domain, via
%    "inRS" routine.
% 4. plot the boundary of the domain and the points.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------

clear all; clf;


% ------------------------------ Settings ---------------------------------

% An equispaced tensor. grid is taken in a rectangle containing the domain
% with "Ngrid" equispaced points per direction.
Ngrid=100;



% ----------------------------- Main code ---------------------------------

%--------------------------------------------------------------------------
% 1. Make NURBS structure (define boundary), just knowing
%
% * control points "P"
% * knots in [0,1]
% * weights
% * order
%
% In this case set the first string as "free", to state that is defined
% without a certain geometric structure of circular, ellptical or polygonal
% type.
%--------------------------------------------------------------------------

geometry_NURBS=makeNURBSarc('free',...
    'P',[0 0; 1 0; 1 1; -2 1; 0 0],...
    'knots',[0 0 0 1/3 2/3 1 1 1],...
    'weights',[1 1 3 2 1],...
    'order',3);

% join piecewise NURBS: not necessary, just one piece of NURBS!
% geometry_NURBS=joinNURBSarcs(geometry_NURBS);


%--------------------------------------------------------------------------
% 2. Define points to test.
%--------------------------------------------------------------------------
pts=ptsRS(geometry_NURBS,Ngrid);

%--------------------------------------------------------------------------
% 2. Test indomain
%--------------------------------------------------------------------------

[in,in_doubts]=inRS(pts,geometry_NURBS);

%--------------------------------------------------------------------------
% 2. Plot domain and control points polygon.
%--------------------------------------------------------------------------
h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)

hold on;
axis equal;

% Plot boundary
plotNURBSPL(geometry_NURBS);

% Plot points inside the domain
iok=find(in == 1);
Xin=pts(iok,1); Yin=pts(iok,2);
plot(Xin,Yin,'go','MarkerSize',2);


% Plot points not inside the domain
iko=find(not(in == 1));
Xo=pts(iko,1); Yo=pts(iko,2);
plot(Xo,Yo,'ro','MarkerSize',2);

% Title
titlesrt=strcat('Indomain test:  ',num2str(Ngrid^2), ' points');
title(titlesrt);

hold off;

%--------------------------------------------------------------------------
% 3. Display statistics.
%--------------------------------------------------------------------------
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             NURBS CUBATURE TEST \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n');
fprintf('\n \t # TRIAL POINTS                : %6.0f',size(pts,1));
fprintf('\n \t # TRIAL POINTS IN             : %6.0f',size(Xin,1));
fprintf('\n');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             PLOT DESCRIPTION \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t * Green dots: points inside the domain.   \n \t');
fprintf('\n \t * Red dots: points not inside the domain.   \n \t');
fprintf('\n \t ------------------------------------------- \n');



