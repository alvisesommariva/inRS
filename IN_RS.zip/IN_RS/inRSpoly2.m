
function [in,XV,YV,TV]=inRSpoly2(pts,structure_RS,Nsub)

if nargin < 3, Nsub=10000; end

[SxNV,SxDV,SyNV,SyDV]=NURBSPL2ratsplines(structure_RS,'pp');

TV=[]; XV=[]; YV=[];
for k=1:length(SxNV)
    SxNVL=SxNV(k); SxDVL=SxDV(k);
    SyNVL=SyNV(k); SyDVL=SyDV(k);
    knotsL=SxNVL.breaks; knotsL=unique(knotsL);
    for j=1:length(knotsL)-1
        t0=knotsL(j); t1=knotsL(j+1);
        TVL=(linspace(t0,t1,Nsub))'; TVL=TVL(1:end-1);
        TV=[TV; TVL k*ones(size(TVL)) j*ones(size(TVL))];
        XVL=ppval(SxNVL,TVL)./ppval(SxDVL,TVL);
        XV=[XV; XVL k*ones(size(XVL)) j*ones(size(XVL))];
        YVL=ppval(SyNVL,TVL)./ppval(SyDVL,TVL);
        YV=[YV; YVL k*ones(size(YVL)) j*ones(size(YVL))];
    end
end

[TV,iunique]=unique(TV(:,1));
XV=XV(iunique,:); YV=YV(iunique,:);

if not(XV(1,1) == XV(end,1)) | not(YV(1,1) == YV(end,1))
    xv=[XV(:,1); XV(1,1)]; yv=[YV(:,1); YV(1,1)];
else
    xv=XV(:,1); yv=YV(:,1);
end

node=[xv yv];

if not(isempty(pts))
    in = inpoly2(pts,node);
else
    in=[];
end









