
function demo_nurbs_indomain_01

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating:
% 1. how to define a NURBS on a composite boundary, using arcs of disks,
%    ellipses, segments, polygons and "free NURBS". The routines work on
%    piecewise NURBS of different order.
% 2. how too define a grid that is defined in the bounding box of the
%    domain.
% 3. how to get an indomain test on the desired domain, via
%    "inRS" routine.
% 4. plot the boundary of the domain.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------

% ------------------------------ Settings ---------------------------------

% An equispaced tensor. grid is taken in a rectangle containing the domain
% with "Ngrid" equispaced points per direction.
Ngrid=100;



% ----------------------------- Main code ---------------------------------

%--------------------------------------------------------------------------
% 1. Make NURBS structure (define boundary).
%--------------------------------------------------------------------------

% add arc of a disk
geometry_NURBS(1)=makeNURBSarc('disk_arc',...
    'center',[0 0],'angles',[0 pi/2],'radius',1);

% compute first point of the piecewise NURBS domain
Pinit=firstpointNURBSPL(geometry_NURBS(1));

% compute last point of the so made NURBS
Pend=lastpointNURBSPL(geometry_NURBS(end));

% add arc of an ellipse
geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
    'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
    'tilt_angle',0);

% compute last point of the so made NURBS
Pend=lastpointNURBSPL(geometry_NURBS(end));

% add segment
geometry_NURBS(3)=makeNURBSarc('segment','extrema',[Pend; 0 Pend(2)]);

% compute first point of the piecewise NURBS domain
Pinit=firstpointNURBSPL(geometry_NURBS);

% "close" the boundary with a "free" NURBS.
geometry_NURBS(4)=makeNURBSarc('free',...
    'P',[0 Pend(2); -1.9 0.3; -1.8 0.5; Pinit],...
    'knots',[0 0 0 0 1 1 1 1],'weights',[1 1 2 1],'order',4);

% join piecewise NURBS (the components of "geometry_NURBS" are larger than
% 1).
geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);



%--------------------------------------------------------------------------
% 2. Define points to test.
%--------------------------------------------------------------------------
pts=ptsRS(geometry_NURBS,Ngrid);

%--------------------------------------------------------------------------
% 2. Test indomain
%--------------------------------------------------------------------------

[in,in_doubts]=inRS(pts,geometry_NURBS);

%--------------------------------------------------------------------------
% 2. Plot domain and control points polygon.
%--------------------------------------------------------------------------
h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)

hold on;
axis equal;

% Plot boundary
plotNURBSPL(geometry_NURBS);

% Plot points inside the domain
iok=find(in == 1);
Xin=pts(iok,1); Yin=pts(iok,2);
plot(Xin,Yin,'go','MarkerSize',2);


% Plot points not inside the domain
iko=find(not(in == 1));
Xo=pts(iko,1); Yo=pts(iko,2);
plot(Xo,Yo,'ro','MarkerSize',2);

% Title
titlesrt=strcat('Indomain test:  ',num2str(Ngrid^2), ' points');
title(titlesrt);

hold off;

%--------------------------------------------------------------------------
% 3. Display statistics.
%--------------------------------------------------------------------------
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             NURBS CUBATURE TEST \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n');
fprintf('\n \t # TRIAL POINTS                : %6.0f',size(pts,1));
fprintf('\n \t # TRIAL POINTS IN             : %6.0f',size(Xin,1));
fprintf('\n');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             PLOT DESCRIPTION \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t * Green dots: points inside the domain.   \n \t');
fprintf('\n \t * Red dots: points not inside the domain.   \n \t');
fprintf('\n \t ------------------------------------------- \n');



