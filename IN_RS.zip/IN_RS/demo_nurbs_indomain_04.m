
function [M0,M1,M2,S01,S21]=demo_nurbs_indomain_04(domain_type,Npts)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo comparing POLYGONAL vs INRS indomain:
% 1. how to define a NURBS on a composite boundary, using arcs of disks,
%    ellipses, segments, polygons and "free NURBS". The routines work on
%    piecewise NURBS of different order.
%    To this purpose see the MATLAB function "define_domain" at the
%    bottom of this demo.
% 2. performing indomain on a polygon with many sides approximating the
%    NURBS-shaped domain either with MATLAB built-in "indomain", either
%    with the new routine "inpoly2".
% 3. doing the same operation with "inRS", suitable for NURBS-shaped
%    domains.
%--------------------------------------------------------------------------
% Example
%--------------------------------------------------------------------------
% >> demo_nurbs_indomain_04;
% 
%  	 ......................................................
%  	 DOMAIN         :          1
%  	 # BLOCKS       :          1
%  	 # SUM SUBBLOCKS:         19
%  	 # BOXES        :       3001
%  	 # INPOLYG.SIDES:     749985
%  
%  	 AE: X : 3.0e-11, Y:6.0e-11
%  
%  	 # POINTSET     :       1000
%  	  TYPE          :halton
% 
%  	 ................. CPU ( 10 tests) ....................
%  	 * [inRS 21  ]: 4.9e-03 
%  	 * [inRS 22  ]: 3.6e-03 
%  	 > [rat 21/22]:  1.35 
%  	 * [inpoly2  ]: 2.2e-01 
%  	 * [inRS 22  ]: 3.6e-03 
%  	 > [rat ip/22]:  61.4 
%  	 * [boxes    ]: 2.8e-03 
%  	 ......................................................
%  
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: December 30, 2021;
% Checked: January 06, 2022 (22:25).
%--------------------------------------------------------------------------

if not(isfile('inpoly2.m'))
    fprintf(2,'\n \t For comparing with indomains routines for polygons ');
    fprintf(2,'\n \t download inpoly2.m by Darren Engwirda (2022). ');
    fprintf(2,'\n \t Suite: INPOLY: A fast points-in-polygon test');
    fprintf(2,'\n \t url: https://github.com/dengwirda/inpoly  ');
    % url='https://github.com/dengwirda/inpoly';
    % web(url);
    flag_inpoly=0;
else
    flag_inpoly=1;
end


% Nbox: number of sub-boxes in each monotone box.
Nbox22=200;
Nbox21=70;

% Number of tests being performed to get the median cputime.
Ntests=10;

% "safe_mode": 1: thorough analysis of the pointset, 0: discard doubtful
% points.
safe_mode=0;

% NURBS-shaped domain (see the routine "define_domain" defined below).
if nargin < 1, domain_type=1; end

% Npts: cardinality of the pointset (indomain trial points in bounding box).
if nargin < 2, Npts=1000; end

% Nsub: cardinality of the polygon is "# sides * Nsub".
%       if "Nsub=[]" the code decides a suitable "Nsub"
Nsub=50000;

% Pointset used. It can be 'grid', 'halton' or 'rand'.
% Important: 'grid' uses "Npts^2" points, while all the other preferences 
%            use "Npts" points.
pointstring='halton';



%-------------------------- Main code below -------------------------------

% Define domain.
% % fprintf(2,,'\n \t * Define domain.')
[geometry_NURBS,domain_str]=define_domain(domain_type);

% Define pointset
% % fprintf(2,,'\n \t * Define pointset.')
pts=ptsRS(geometry_NURBS,Npts,[],pointstring);

% Applying "inRS" (2021 version).
% fprintf(2,'\n \t * Applying "inRS 21".')
for k=1:Ntests
    tic;
    [in0,in_doubts,SxNV,SxDV,SyNV,SyDV,boxVxy,turn_pts_X, ...
        turn_pts_Y]=inRS_21([],geometry_NURBS,Nbox21,safe_mode);
    cpusBB(k)=toc;
end


% Applying "inRS" (2021 version).
% fprintf(2,'\n \t * Applying "inRS 21".')
for k=1:Ntests
    tic;
    [in0,in_doubts,SxNV,SxDV,SyNV,SyDV,boxVxy,turn_pts_X, ...
        turn_pts_Y]=inRS_21(pts,geometry_NURBS,Nbox21,safe_mode);
    cpus0(k)=toc;
end

% Applying "inRS" (2022 version).
% fprintf(2,'\n \t * Applying "inRS".')
for k=1:Ntests
    tic;
    [in1,in_doubts,SxNV,SxDV,SyNV,SyDV,boxVxy,turn_pts_X, ...
        turn_pts_Y]=inRS(pts,geometry_NURBS,Nbox22,safe_mode);
    cpus1(k)=toc;
end


% Applying "inRSpoly2".
% fprintf(2,'\n \t * Applying "inRSpoly2".')
if flag_inpoly
    for k=1:Ntests
        tic;
        [in2,XV,YV,TV]=inRSpoly2(pts,geometry_NURBS,Nsub);
        cpus2(k)=toc;
    end
end

% Applying "inRSinpolygon".
% % fprintf(2,'\n \t * Applying "inRSinpolygon".')
% for k=1:Ntests
%     tic;
%     [in3,XV,YV,TV]=inRSinpolygon(pts,geometry_NURBS,Nsub);
%     cpus3(k)=toc;
% end


% Applying "inRS".
% % fprintf(2,,'\n \t * Determining approximation errors.')
if flag_inpoly
    [~,XVT,YVT,TVT]=inRSpoly2([],geometry_NURBS,Nsub*20);

    TVT1=TVT(:,1); [TVT1,iunique]=unique(TVT1);
    XVT=XVT(iunique,:); XVT1=XVT(:,1);
    YVT=YVT(iunique,:); YVT1=YVT(:,1);

    XVTa = interp1(TV(:,1),XV(:,1),TVT1,'linear');
    YVTa = interp1(TV(:,1),YV(:,1),TVT1,'linear');

    iX=isnan(XVTa); iX=find(iX == 0);
    iY=isnan(XVTa); iY=find(iY == 0);

    AEX=norm(XVT(iX,1)-XVTa(iX,1),inf);
    AEY=norm(YVT(iY,1)-YVTa(iX,1),inf);

end




fprintf('\n \t ......................................................');
fprintf('\n \t DOMAIN         : %10.0f',domain_type)

Nspl=length(geometry_NURBS);
subs=0;
for k=1:Nspl
    geometry_NURBSL=geometry_NURBS(k);
    subs=subs+length(geometry_NURBSL.knots)-1;
end
fprintf('\n \t # BLOCKS       : %10.0f',Nspl)
fprintf('\n \t # SUM SUBBLOCKS: %10.0f',subs)
fprintf('\n \t # BOXES        : %10.0f',size(boxVxy,1))
if flag_inpoly
fprintf('\n \t # INPOLYG.SIDES: %10.0f',length(XV));
    fprintf('\n \n \t AE: X : %1.1e, Y:%1.1e',AEX,AEY);
end
card_pts=size(pts,1);
fprintf('\n \n \t # POINTSET     : %10.0f',card_pts)
fprintf('\n \t  TYPE          :'); disp(pointstring);
% card_in21_1=length(find(in0 == 1));
% fprintf('\n \t * inRS 21 1        : %10.0f',card_in21_1)
% card_in21_05=length(find(in0 == 0.5));
% fprintf('\n \t   inRS 21 0.5      : %10.0f',card_in21_05)
%
%
% card_in1=length(find(in1 == 1));
% fprintf('\n \t * inRS 22 1        : %10.0f',card_in1)
% card_in05=length(find(in1 == 0.5));
% fprintf('\n \t   inRS 22 0.5      : %10.0f',card_in05)
%
% card_ip2=length(find(in2 == 1));
% fprintf('\n \t * inpoly2  1       : %10.0f',card_ip2)

% card_ip3=length(find(in3 == 1));
% fprintf('\n \t inpoly3  1    : %10.0f',card_ip3)
fprintf('\n \t ................. CPU (%3.0f tests) ....................',...
    Ntests);
M0=median(cpus0); M1=median(cpus1); M2=median(cpus2); 
S01=M0/M1; S21=M2/M1;
fprintf('\n \t * [inRS 21  ]: %1.1e ',M0);
fprintf('\n \t * [inRS 22  ]: %1.1e ',M1);
fprintf('\n \t > [rat 21/22]: %5.3g ',M0/M1);

if flag_inpoly
    fprintf('\n \t * [inpoly2  ]: %1.1e ',M2);
    fprintf('\n \t * [inRS 22  ]: %1.1e ',M1);
    fprintf('\n \t > [rat ip/22]: %5.3g ',M2/M1);
end

fprintf('\n \t * [boxes    ]: %1.1e ',median(cpusBB));
% fprintf('\n \t * [inpolygon]: %1.1e ',median(cpus3));
% fprintf('\n \t * [rat      ]: %5.3f ',median(cpus3)/M1);
fprintf('\n \t ......................................................');
fprintf('\n \n');
















%--------------------------------------------------------------------------
% ATTACHED ROUTINES
%--------------------------------------------------------------------------

function [geometry_NURBS,domain_str]=define_domain(example)

switch example

    case 1 % M-shaped domain

        domain_str='S(3): M shaped domain';
        order=3;
        P=[-1 1; -1 0; -1 -1; -0.6 -1; -0.6 0; -0.6 0.6; 0 0; 0.6 0.6; ...
            0.6 0; 0.6 -1; 1 -1; 1 0; 1 1; 0.6 1; 0 0.4; -0.6 1; -1 1];
        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 2

        domain_str='S(4): domain defined by a disk, an ellipse, a segment';
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',[0 0],'angles',[pi/2 3*pi/2],'ell_axis',[0.5 1],...
            'tilt_angle',0);

        % add a final segment
        Pend=lastpointNURBSPL(geometry_NURBS(2));
        Pinit=firstpointNURBSPL(geometry_NURBS(1));
        geometry_NURBS(3)=makeNURBSarc('segment','vertices',[Pend; Pinit]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

    case 3 % lune-like
        domain_str='S(5): lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        knots=[0 0 0 .15 .25 .25 .5 .5 .75 .75 1 1 1];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1];
        order=3;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 4 % square/disk difference
        domain_str='domain 4';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));


        % add arc of an ellipse
        v=[0.5 0;0.5 0.5;0 0.5];
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);





    case 5 % polygon/disk union
        domain_str='domain 5';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0.25 0.25],'angles',[pi pi+pi/2],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.4 0.05; 0.5 0.25; 0.45 0.45; 0.3 0.5;0.1 0.45]; % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);





    case 6 % polygon/disk union
        domain_str='domain 6';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.25 0.2; 0.2 0.25];  % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);



    case 7 % polygon/disk union
        domain_str='domain 7';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.4 0.05; 0.5 0.25; 0.45 0.45; 0.3 0.5;0.1 0.45]; % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);


    case 8 % polygon/disk union
        domain_str='domain 8: square';

        v=[0 0; 1 0; 1 1; 0 1; 0 0];
        geometry_NURBS(1)=makeNURBSarc('polygonal_arc',...
            'vertices',v);


    case 9 % polygon/disk union
        domain_str='domain 9: union of rectangles';

        % add arc of an ellipse
        v=[0 0; 1 0; 1 1; 2 1; 2 2; 1 2; 1 1.5; 0 1.5; 0 1.25; -0.5 1.25; ...
            -0.5 0; 0 0];
        geometry_NURBS(1)=makeNURBSarc('polygonal_arc',...
            'vertices',v);










    case 10
        domain_str='domain 10: square';
        P=[0 0; 1 0; 1 1; 0 1; 0 0];
        geometry_NURBS=makeNURBSarc('polygonal_arc','vertices',P);

    case 11 % circle
        domain_str='domain 11: circle';
        geometry_NURBS=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 2*pi],'radius',1);

    case 12 % lune-like
        domain_str='domain 12: lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        order=3;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free',...
            'P',P,'knots',knots,'weights',w,'order',order);


    case 13 % tau-like-symbol
        domain_str='domain 13: tau-like-symbol';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5;  ...
            0.2 -0.45; -0.4 -0.4; 0 -1; 1 -1;  1 0];
        order=3;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 14 % cubic-domain
        domain_str='domain 14: cubic-domain: leaf';
        P=[1 0; 1 1; 0 1; -1 1; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);



    case 15 % cubic-domain: nut
        domain_str='domain 15: cubic-domain: slanted nut';
        P=[1 0; 1 1; 0 1; -1 0.6; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 16 % cubic-domain: slanted boomerang
        domain_str='domain 16: cubic-domain: golf club';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.4 0.6; 0 0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c/2 1 c/4 1 c/4 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 17 % cubic-domain: nut
        domain_str='domain 17: cubic-domain: dino head';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 -1; 0 0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c/2 1 c/4 1 c/4 1 1 c 1];


        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 18 % cubic-domain: slanted boomerang
        domain_str='domain 18: cubic-domain: tadpole';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.4 0.6; 0 -0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 1 1 1 1 1 1 1 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 19 % cubic-domain: nut
        domain_str='domain 19: cubic-domain: nose';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 5 5 5 5 5 5 5 1];


        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 20 % rough-ball
        domain_str='domain 20: rough ball';
        order=3;
        sidesL=20;
        t=linspace(0,2*pi,sidesL); t=t';
        P=[cos(t) sin(t)]; P=[P(1:end-1,:); P(1,:)];
        knots_mid=linspace(0.1,0.9,sidesL-order);
        knots=[zeros(1,order) knots_mid ones(1,order)];
        M=size(P,1);
        % w=rand(1,M);
        w=[ 8.258169774895474e-01
            5.383424352600571e-01
            9.961347166268855e-01
            7.817552875318368e-02
            4.426782697754463e-01
            1.066527701805844e-01
            9.618980808550537e-01
            4.634224134067444e-03
            7.749104647115024e-01
            8.173032206534330e-01
            8.686947053635097e-01
            8.443584551091032e-02
            3.997826490988965e-01
            2.598704028506542e-01
            8.000684802243075e-01
            4.314138274635446e-01
            9.106475944295229e-01
            1.818470283028525e-01
            2.638029165219901e-01
            1.455389803847170e-01]';

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 21 % L-shaped domain

        domain_str='domain 21: L shaped domain';
        P=[-1 1; -1 -1; 1 -1; 1 -0.6; -0.6 -0.6; -0.6 1; -1 1]; % 7 points
        order=3;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        w=[0.2 5 10 10 100 5 0.2];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 22 % variable order
        domain_str='domain 22, defined by a disk, an ellipse and a segment';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],...
            'ell_axis',[1 2],'tilt_angle',0);

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(2));

        % "close" the boundary with a segment
        geometry_NURBS(3)=makeNURBSarc('segment','extrema',...
            [Pend; Pinit]);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);



    case 23 % variable order

        domain_str1='domain 23, defined by a disk, an ellipse, a segment';
        domain_str2=' and a free NURBS (variable order)';
        domain_str=strcat(domain_str1,domain_str2);

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(end));

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(end));

        % add segment
        geometry_NURBS(3)=makeNURBSarc('segment','extrema',[Pend; 0 Pend(2)]);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS);

        % "close" the boundary with a "free" NURBS.
        geometry_NURBS(4)=makeNURBSarc('free',...
            'P',[0 Pend(2); -1.9 0.3; -1.8 0.5; Pinit],...
            'knots',[0 0 0 0 1 1 1 1],'weights',[1 1 2 1],'order',4);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

    case 24 % variable order

        domain_str='domain 24, defined by a disk, an ellipse, a segment';
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',[0 0],'angles',[pi/2 3*pi/2],'ell_axis',[0.5 1],...
            'tilt_angle',0);

        % add a final segment
        Pend=lastpointNURBSPL(geometry_NURBS(2));
        Pinit=firstpointNURBSPL(geometry_NURBS(1));
        geometry_NURBS(3)=makeNURBSarc('segment','vertices',[Pend; Pinit]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);


    case 25 % cubic-domain: nut
        domain_str='domain 25: 15-inverse cubic-domain: slanted nut';
        P=[1 0; 1 1; 0 1; -1 0.6; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        P=P(:,[2 1]);
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 26 % polygon/disk union
        domain_str='domain 6';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.25 0.13; 0.13 0.25];  % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

end





